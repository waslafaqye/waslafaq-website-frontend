class VisionData {
    visionList: VisionItemData [];

    constructor(visionList: VisionItemData[]) {
        this.visionList = visionList;
    }
}