class ContactUsInfoData {
    title: string;
    info: string;
    logo: string;

    constructor(title: string, info: string, logo: string) {
        this.logo = logo;
        this.info = info;
        this.title = title;
    }
}