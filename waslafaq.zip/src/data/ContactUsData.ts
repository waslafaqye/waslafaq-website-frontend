class ContactUsData {

    contactUsInfoList: ContactUsInfoData[];

    constructor(content: string, contactUsInfoList: ContactUsInfoData[]) {
        this.contactUsInfoList = contactUsInfoList;
    }

}