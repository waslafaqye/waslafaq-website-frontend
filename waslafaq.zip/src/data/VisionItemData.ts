class VisionItemData {
    title: string;
    content: string;

    constructor(title: string, content: string) {
        this.content = content;
        this.title = title;
    }
}